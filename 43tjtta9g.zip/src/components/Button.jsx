import React from 'react'

export default function Button({ children, type='button', variant='default', ...rest }){
  const cls = 'btn ' + (variant === 'primary' ? 'primary' : '')
  return <button className={cls} type={type} {...rest}>{children}</button>
}
