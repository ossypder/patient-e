import React from 'react'

export default function AppointmentCard({ appt, onCancel }){
  return (
    <div className="card">
      <div className="header">
        <h3>{appt.doctorName}</h3>
        <span className="badge">{new Date(appt.date).toLocaleDateString()} @ {appt.time}</span>
      </div>
      <small className="muted">Department: {appt.department}</small><br/>
      <small className="muted">Reason: {appt.reason || '—'}</small>
      {onCancel && <div style={{marginTop:12}}><button className="btn" onClick={() => onCancel(appt.id)}>Cancel</button></div>}
    </div>
  )
}
