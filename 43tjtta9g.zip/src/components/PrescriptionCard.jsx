import React from 'react'

export default function PrescriptionCard({ rx }){
  return (
    <div className="card">
      <div className="header">
        <h3>{rx.medicineName}</h3>
        <span className="badge">{rx.frequency}</span>
      </div>
      <div className="row">
        <small className="muted">Doctor: {rx.doctorName}</small>
        <small className="muted">Start: {new Date(rx.startDate).toLocaleDateString()}</small>
        <small className="muted">End: {new Date(rx.endDate).toLocaleDateString()}</small>
      </div>
      <small className="muted">Notes: {rx.notes || '—'}</small>
    </div>
  )
}
