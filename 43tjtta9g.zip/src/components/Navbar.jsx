import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'

export default function Navbar(){
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const onLogout = () => { logout(); navigate('/login') }
  return (
    <nav className="nav">
      <NavLink to="/dashboard">🏥 Patient Tracker</NavLink>
      <NavLink to="/dashboard">Dashboard</NavLink>
      <NavLink to="/book">Book</NavLink>
      <NavLink to="/prescriptions">Prescriptions</NavLink>
      <div className="spacer" />
      {user ? (
        <>
          <span className="badge">Hi, {user.firstName}</span>
          <button className="btn" onClick={onLogout}>Logout</button>
        </>
      ) : (
        <>
          <NavLink to="/login">Login</NavLink>
          <NavLink to="/register">Register</NavLink>
        </>
      )}
    </nav>
  )
}
