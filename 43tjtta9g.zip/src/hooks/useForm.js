import { useState } from 'react'

export default function useForm(initial){
  const [values, setValues] = useState(initial)
  const [errors, setErrors] = useState({})

  const handleChange = (e) => {
    const { name, value } = e.target
    setValues(v => ({ ...v, [name]: value }))
  }

  const validate = (rules) => {
    const errs = {}
    Object.entries(rules).forEach(([field, rule]) => {
      const val = (values[field] ?? '').toString().trim()
      if(rule?.required && !val) errs[field] = 'Required'
      if(rule?.pattern && val && !rule.pattern.test(val)) errs[field] = rule.message || 'Invalid'
      if(rule?.minLength && val && val.length < rule.minLength) errs[field] = `Min ${rule.minLength} chars`
    })
    setErrors(errs)
    return Object.keys(errs).length === 0
  }

  const reset = () => setValues(initial)

  return { values, setValues, errors, handleChange, validate, reset }
}
