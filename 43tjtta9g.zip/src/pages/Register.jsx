import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import useForm from '../hooks/useForm.js'
import FormField from '../components/FormField.jsx'
import Button from '../components/Button.jsx'
import { useAuth } from '../context/AuthContext.jsx'

export default function Register(){
  const { register } = useAuth()
  const navigate = useNavigate()
  const { values, handleChange, validate, errors } = useForm({ firstName:'', lastName:'', email:'', password:'', confirmPassword:'' })
  const [serverError, setServerError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const onSubmit = async (e) => {
    e.preventDefault()
    setServerError('')
    const ok = validate({
      firstName: { required: true },
      lastName: { required: true },
      email: { required: true, pattern: /.+@.+\..+/, message: 'Enter a valid email' },
      password: { required: true, minLength: 6 },
      confirmPassword: { required: true }
    })
    if(!ok) return
    if(values.password !== values.confirmPassword){
      setServerError('Passwords do not match')
      return
    }
    setSubmitting(true)
    try {
      await register({ firstName: values.firstName, lastName: values.lastName, email: values.email, password: values.password })
      navigate('/dashboard')
    } catch(err){
      setServerError(err.message)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="card" style={{maxWidth:520, margin:'24px auto'}}>
      <h2>Create account</h2>
      <form onSubmit={onSubmit}>
        <div className="row">
          <div style={{flex:1}}>
            <FormField label="First name" name="firstName" value={values.firstName} onChange={handleChange} required />
            {errors.firstName && <small className="muted">{errors.firstName}</small>}
          </div>
          <div style={{flex:1}}>
            <FormField label="Last name" name="lastName" value={values.lastName} onChange={handleChange} required />
            {errors.lastName && <small className="muted">{errors.lastName}</small>}
          </div>
        </div>
        <FormField label="Email" name="email" type="email" value={values.email} onChange={handleChange} required />
        {errors.email && <small className="muted">{errors.email}</small>}
        <FormField label="Password" name="password" type="password" value={values.password} onChange={handleChange} required />
        {errors.password && <small className="muted">{errors.password}</small>}
        <FormField label="Confirm Password" name="confirmPassword" type="password" value={values.confirmPassword} onChange={handleChange} required />
        {errors.confirmPassword && <small className="muted">{errors.confirmPassword}</small>}
        {serverError && <small className="muted">{serverError}</small>}
        <Button type="submit" variant="primary" disabled={submitting}>{submitting ? 'Creating...' : 'Register'}</Button>
      </form>
      <small>Already have an account? <Link to="/login">Login</Link></small>
    </div>
  )
}
