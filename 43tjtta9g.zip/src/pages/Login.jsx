import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import useForm from '../hooks/useForm.js'
import FormField from '../components/FormField.jsx'
import Button from '../components/Button.jsx'
import { useAuth } from '../context/AuthContext.jsx'

export default function Login(){
  const { login } = useAuth()
  const navigate = useNavigate()
  const { values, handleChange, validate, errors } = useForm({ email: '', password: '' })
  const [serverError, setServerError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const onSubmit = async (e) => {
    e.preventDefault()
    setServerError('')
    const ok = validate({
      email: { required: true, pattern: /.+@.+\..+/, message: 'Enter a valid email' },
      password: { required: true, minLength: 6 }
    })
    if(!ok) return
    setSubmitting(true)
    try {
      await login(values.email, values.password)
      navigate('/dashboard')
    } catch(err){
      setServerError(err.message)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="card" style={{maxWidth:480, margin:'24px auto'}}>
      <h2>Login</h2>
      <form onSubmit={onSubmit}>
        <FormField label="Email" name="email" type="email" value={values.email} onChange={handleChange} required />
        {errors.email && <small className="muted">{errors.email}</small>}
        <FormField label="Password" name="password" type="password" value={values.password} onChange={handleChange} required />
        {errors.password && <small className="muted">{errors.password}</small>}
        {serverError && <small className="muted">{serverError}</small>}
        <Button type="submit" variant="primary" disabled={submitting}>{submitting ? 'Signing in...' : 'Login'}</Button>
      </form>
      <small>New here? <Link to="/register">Create an account</Link></small>
    </div>
  )
}
