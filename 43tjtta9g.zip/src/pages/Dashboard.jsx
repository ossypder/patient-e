import React from 'react'
import { useAuth } from '../context/AuthContext.jsx'
import { useData } from '../context/DataContext.jsx'
import AppointmentCard from '../components/AppointmentCard.jsx'
import { Link } from 'react-router-dom'

export default function Dashboard(){
  const { user } = useAuth()
  const { appointments, cancelAppointment } = useData()

  return (
    <div>
      <div className="card">
        <h2>Welcome, {user.firstName} {user.lastName}</h2>
        <div className="row">
          <span className="badge">{user.email}</span>
        </div>
      </div>

      <div className="header">
        <h2>Upcoming Appointments</h2>
        <Link to="/book" className="btn">+ Book New</Link>
      </div>
      {appointments.length === 0 ? (
        <div className="card"><small className="muted">No appointments yet.</small></div>
      ) : (
        <div className="grid">
          {appointments.map(a => <AppointmentCard key={a.id} appt={a} onCancel={cancelAppointment} />)}
        </div>
      )}
    </div>
  )
}
