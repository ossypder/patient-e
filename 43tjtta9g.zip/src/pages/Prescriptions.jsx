import React from 'react'
import { useData } from '../context/DataContext.jsx'
import PrescriptionCard from '../components/PrescriptionCard.jsx'

export default function Prescriptions(){
  const { prescriptions } = useData()
  return (
    <div>
      <h2>Prescriptions</h2>
      {prescriptions.length === 0 ? (
        <div className="card"><small className="muted">No prescriptions available.</small></div>
      ) : (
        <div className="grid">
          {prescriptions.map(p => <PrescriptionCard key={p.id} rx={p} />)}
        </div>
      )}
    </div>
  )
}
