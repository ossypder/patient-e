import React, { useState } from 'react'
import { useAuth } from '../context/AuthContext.jsx'
import { useData } from '../context/DataContext.jsx'
import useForm from '../hooks/useForm.js'
import FormField from '../components/FormField.jsx'
import Button from '../components/Button.jsx'
import { useNavigate } from 'react-router-dom'

export default function BookAppointment(){
  const { user } = useAuth()
  const { doctors, bookAppointment } = useData()
  const navigate = useNavigate()
  const today = new Date().toISOString().slice(0,10)
  const { values, handleChange, validate, errors } = useForm({ doctorId:'', date: today, time:'09:00', reason:'' })
  const [serverError, setServerError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const onSubmit = async (e) => {
    e.preventDefault()
    setServerError('')
    const ok = validate({
      doctorId: { required: true },
      date: { required: true },
      time: { required: true }
    })
    if(!ok) return
    setSubmitting(true)
    try {
      await bookAppointment({ userId: user.id, ...values })
      navigate('/dashboard')
    } catch(err){
      setServerError(err.message)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="card" style={{maxWidth:640, margin:'0 auto'}}>
      <h2>Book Appointment</h2>
      <form onSubmit={onSubmit}>
        <FormField
          label="Doctor"
          name="doctorId"
          type="select"
          value={values.doctorId}
          onChange={handleChange}
          required
          options={doctors.map(d => ({ value: d.id, label: `${d.name} — ${d.department}` }))}
        />
        {errors.doctorId && <small className="muted">{errors.doctorId}</small>}

        <div className="row">
          <div style={{flex:1}}>
            <FormField label="Date" name="date" type="date" value={values.date} onChange={handleChange} required />
            {errors.date && <small className="muted">{errors.date}</small>}
          </div>
          <div style={{flex:1}}>
            <FormField label="Time" name="time" type="time" value={values.time} onChange={handleChange} required />
            {errors.time && <small className="muted">{errors.time}</small>}
          </div>
        </div>

        <FormField label="Reason (optional)" name="reason" value={values.reason} onChange={handleChange} placeholder="e.g., follow-up, test results..." />

        {serverError && <small className="muted">{serverError}</small>}
        <Button type="submit" variant="primary" disabled={submitting}>{submitting ? 'Booking...' : 'Book Appointment'}</Button>
      </form>
    </div>
  )
}
