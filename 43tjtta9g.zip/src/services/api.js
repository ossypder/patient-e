import { v4 as uuid } from 'uuid'

const LS = {
  users: 'pmats_users',
  currentUser: 'pmats_current_user',
  doctors: 'pmats_doctors',
  appointments: 'pmats_appointments',
  prescriptions: 'pmats_prescriptions'
}

function read(key, fallback = []){
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback } catch { return fallback }
}
function write(key, value){ localStorage.setItem(key, JSON.stringify(value)) }

export function seed(){
  if(!read(LS.doctors).length){
    write(LS.doctors, [
      { id: 'd1', name: 'Dr. A. Sharma', department: 'Cardiology' },
      { id: 'd2', name: 'Dr. R. Mehta', department: 'Dermatology' },
      { id: 'd3', name: 'Dr. N. Iyer', department: 'Orthopedics' },
      { id: 'd4', name: 'Dr. S. Banerjee', department: 'Pediatrics' },
    ])
  }
  if(!read(LS.appointments).length){
    write(LS.appointments, [])
  }
  if(!read(LS.prescriptions).length){
    // demo prescriptions assigned to user after registration/login by user id
    write(LS.prescriptions, [])
  }
}

export function getDoctors(){ return read(LS.doctors) }

export function getCurrentUser(){ return read(LS.currentUser, null) }

export function register({ firstName, lastName, email, password }){
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const users = read(LS.users)
      if(users.some(u => u.email === email)) return reject(new Error('Email already registered'))
      const user = { id: uuid(), firstName, lastName, email, password }
      users.push(user)
      write(LS.users, users)
      write(LS.currentUser, user)
      // add sample prescriptions on first register
      const base = read(LS.prescriptions)
      base.push(
        { id: uuid(), userId: user.id, medicineName: 'Atorvastatin 10mg', frequency: 'Once daily', startDate: new Date(), endDate: new Date(Date.now()+30*86400000), doctorName: 'Dr. A. Sharma', notes: 'Take after dinner' },
        { id: uuid(), userId: user.id, medicineName: 'Metformin 500mg', frequency: 'Twice daily', startDate: new Date(), endDate: new Date(Date.now()+60*86400000), doctorName: 'Dr. R. Mehta', notes: 'With meals' },
      )
      write(LS.prescriptions, base)
      resolve(user)
    }, 300)
  })
}

export function login(email, password){
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const users = read(LS.users)
      const user = users.find(u => u.email === email && u.password === password)
      if(!user) return reject(new Error('Invalid credentials'))
      write(LS.currentUser, user)
      resolve(user)
    }, 300)
  })
}

export function logout(){ localStorage.removeItem(LS.currentUser) }

export function getAppointmentsByUser(userId){
  return read(LS.appointments).filter(a => a.userId === userId).sort((a,b) => new Date(b.date) - new Date(a.date))
}
export function getPrescriptionsByUser(userId){
  return read(LS.prescriptions).filter(p => p.userId === userId).sort((a,b) => new Date(b.startDate) - new Date(a.startDate))
}

export function createAppointment({ userId, doctorId, date, time, reason }){
  return new Promise((resolve) => {
    setTimeout(() => {
      const doctors = read(LS.doctors)
      const d = doctors.find(x => x.id === doctorId)
      const appt = {
        id: uuid(),
        userId,
        doctorId,
        doctorName: d?.name ?? 'Doctor',
        department: d?.department ?? 'General',
        date,
        time,
        reason: reason || ''
      }
      const list = read(LS.appointments)
      list.push(appt)
      write(LS.appointments, list)
      resolve(appt)
    }, 300)
  })
}

export function deleteAppointment(id){
  return new Promise((resolve) => {
    setTimeout(() => {
      const list = read(LS.appointments)
      write(LS.appointments, list.filter(x => x.id !== id))
      resolve(true)
    }, 200)
  })
}
