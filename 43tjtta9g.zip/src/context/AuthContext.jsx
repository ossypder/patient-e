import React, { createContext, useContext, useEffect, useState } from 'react'
import * as api from '../services/api.js'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const u = api.getCurrentUser()
    if (u) setUser(u)
    setLoading(false)
  }, [])

  const login = async (email, password) => {
    const u = await api.login(email, password)
    setUser(u)
    return u
  }

  const register = async (payload) => {
    const u = await api.register(payload)
    setUser(u)
    return u
  }

  const logout = () => {
    api.logout()
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(){ return useContext(AuthContext) }
