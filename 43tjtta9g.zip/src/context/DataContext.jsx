import React, { createContext, useContext, useEffect, useState } from 'react'
import * as api from '../services/api.js'
import { useAuth } from './AuthContext.jsx'

const DataContext = createContext(null)

export function DataProvider({ children }){
  const { user } = useAuth()
  const [appointments, setAppointments] = useState([])
  const [prescriptions, setPrescriptions] = useState([])
  const [doctors, setDoctors] = useState([])

  useEffect(() => {
    api.seed() // ensure initial data
    setDoctors(api.getDoctors())
  }, [])

  useEffect(() => {
    if(user){
      setAppointments(api.getAppointmentsByUser(user.id))
      setPrescriptions(api.getPrescriptionsByUser(user.id))
    } else {
      setAppointments([])
      setPrescriptions([])
    }
  }, [user])

  const bookAppointment = async (payload) => {
    const appt = await api.createAppointment(payload)
    setAppointments(a => [appt, ...a])
    return appt
  }

  const cancelAppointment = async (id) => {
    await api.deleteAppointment(id)
    setAppointments(a => a.filter(x => x.id !== id))
  }

  return (
    <DataContext.Provider value={{ appointments, prescriptions, doctors, bookAppointment, cancelAppointment }}>
      {children}
    </DataContext.Provider>
  )
}

export function useData(){ return useContext(DataContext) }
